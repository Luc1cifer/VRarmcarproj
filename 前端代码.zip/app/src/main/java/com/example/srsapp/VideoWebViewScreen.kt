//package com.example.srsapp.ui.theme
//
//import android.webkit.WebView
//import android.webkit.WebViewClient
//import androidx.compose.runtime.Composable
//import androidx.compose.ui.viewinterop.AndroidView
//
//@Composable
//fun VideoWebViewScreen(streamUrl: String) {
//    AndroidView(factory = { context ->
//        WebView(context).apply {
//            webViewClient = WebViewClient()
//            settings.javaScriptEnabled = true
//            loadUrl(streamUrl)
//        }
//    })
//}

package com.example.srsapp

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun VideoWebViewScreen(streamUrl: String) {
    AndroidView(factory = { context ->
        WebView(context).apply {
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = true
            loadUrl(streamUrl)
        }
    })
}


