//package com.example.srsapp
//
//import android.os.Bundle
//import androidx.activity.ComponentActivity
//import androidx.activity.compose.setContent
//import androidx.compose.material3.MaterialTheme
//import androidx.navigation.compose.NavHost
//import androidx.navigation.compose.composable
//import androidx.navigation.compose.rememberNavController
//import com.example.srsapp.ui.theme.LoginScreen
//import com.example.srsapp.ui.theme.RegisterScreen
//import com.example.srsapp.ui.theme.MainScreen
//import com.example.srsapp.ui.theme.VideoWebViewScreen
//
//class MainActivity : ComponentActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContent {
//            MaterialTheme {
//                val navController = rememberNavController()
//                NavHost(navController = navController, startDestination = "login") {
//                    composable("login") {
//                        LoginScreen(
//                            navController = navController,
//                            onLoginSuccess = { },
//                            onRegisterClick = { navController.navigate("register") }
//                        )
//                    }
//                    composable("register") {
//                        RegisterScreen(
//                            navController = navController,
//                            onRegisterSuccess = { navController.popBackStack() }
//                        )
//                    }
//                    composable("main/{username}") { backStackEntry ->
//                        val username = backStackEntry.arguments?.getString("username") ?: ""
//                        MainScreen(username = username, navController = navController)
//                    }
//                    composable("video_view") {
//                        VideoWebViewScreen("http://192.168.xxx.xxx:8080") // 改成实际 MJPEG 地址
//                    }
//                }
//            }
//        }
//    }
//}

package com.example.srsapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.srsapp.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // 注释掉 SRSAppTheme，直接用 MaterialTheme
            MaterialTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "login") {
                    composable("login") {
                        LoginScreen(
                            onLoginSuccess = { username ->
                                navController.navigate("main/$username")
                            },
                            onRegisterClick = {
                                navController.navigate("register")
                            },
                            onSkipClick = {
                                navController.navigate("main/demo_user")
                            }
                        )
                    }
                    composable("register") {
                        RegisterScreen(onRegisterSuccess = {
                            navController.popBackStack()
                        })
                    }
                    composable("main/{username}") { backStackEntry ->
                        val username = backStackEntry.arguments?.getString("username") ?: ""
                        MainScreen(username)
                    }
                    composable("video_view") {
                        VideoWebViewScreen("http://192.168.xxx.xxx:8080")
                    }
                }
            }
        }
    }
}

