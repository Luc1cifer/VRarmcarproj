//package com.example.srsapp.ui.theme
//
//import android.widget.Toast
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.text.KeyboardOptions
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.platform.LocalContext
//import androidx.compose.ui.text.input.KeyboardType
//import androidx.compose.ui.text.input.PasswordVisualTransformation
//import androidx.compose.ui.unit.dp
//import androidx.navigation.NavController
//import com.example.srsapp.ApiClient
//import com.example.srsapp.BaseResponse
//import com.example.srsapp.UserData
//import retrofit2.Call
//import retrofit2.Callback
//import retrofit2.Response
//
//@Composable
//fun RegisterScreen(
//    navController: NavController,
//    onRegisterSuccess: () -> Unit
//) {
//    var username by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//    val context = LocalContext.current
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(16.dp),
//        verticalArrangement = Arrangement.Center
//    ) {
//        TextField(
//            value = username,
//            onValueChange = { username = it },
//            label = { Text("Username") },
//            modifier = Modifier.fillMaxWidth()
//        )
//        Spacer(modifier = Modifier.height(8.dp))
//        TextField(
//            value = password,
//            onValueChange = { password = it },
//            label = { Text("Password") },
//            visualTransformation = PasswordVisualTransformation(),
//            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
//            modifier = Modifier.fillMaxWidth()
//        )
//        Spacer(modifier = Modifier.height(16.dp))
//        Button(
//            onClick = {
//                if (username.isNotEmpty() && password.isNotEmpty()) {
//                    val user = UserData(username, password)
//                    ApiClient.apiService.register(user).enqueue(object : Callback<BaseResponse> {
//                        override fun onResponse(call: Call<BaseResponse>, response: Response<BaseResponse>) {
//                            if (response.isSuccessful && response.body()?.success == true) {
//                                Toast.makeText(context, "注册成功", Toast.LENGTH_SHORT).show()
//                                onRegisterSuccess()
//                                navController.popBackStack()
//                            } else {
//                                Toast.makeText(context, "注册失败: ${response.body()?.message}", Toast.LENGTH_SHORT).show()
//                            }
//                        }
//                        override fun onFailure(call: Call<BaseResponse>, t: Throwable) {
//                            Toast.makeText(context, "网络错误: ${t.message}", Toast.LENGTH_SHORT).show()
//                        }
//                    })
//                } else {
//                    Toast.makeText(context, "请填写用户名和密码", Toast.LENGTH_SHORT).show()
//                }
//            },
//            modifier = Modifier.fillMaxWidth()
//        ) {
//            Text("Register")
//        }
//    }
//}

package com.example.srsapp

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun RegisterScreen(onRegisterSuccess: () -> Unit) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("注册")
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("用户名") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("密码") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            Toast.makeText(context, "模拟注册，无后端请求", Toast.LENGTH_SHORT).show()
            onRegisterSuccess()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("注册")
        }
    }
}


