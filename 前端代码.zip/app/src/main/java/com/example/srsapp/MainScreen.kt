//package com.example.srsapp.ui.theme
//
//import android.Manifest
//import android.content.pm.PackageManager
//import android.location.Location
//import android.widget.Toast
//import androidx.activity.ComponentActivity
//import androidx.activity.compose.rememberLauncherForActivityResult
//import androidx.activity.result.contract.ActivityResultContracts
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.lazy.items
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.platform.LocalContext
//import androidx.compose.ui.unit.dp
//import androidx.core.app.ActivityCompat
//import androidx.navigation.NavController
//import com.example.srsapp.ApiClient
//import com.example.srsapp.BaseResponse
//import com.example.srsapp.VideoItem
//import com.example.srsapp.VideoListResponse
//import com.google.android.gms.location.LocationServices
//import retrofit2.Call
//import retrofit2.Callback
//import retrofit2.Response
//
//@Composable
//fun MainScreen(username: String, navController: NavController) {
//    val context = LocalContext.current
//    var isRecording by remember { mutableStateOf(false) }
//    var videos by remember { mutableStateOf(listOf<VideoItem>()) }
//    var currentLocation by remember { mutableStateOf("未知") }
//
//    val permissionLauncher = rememberLauncherForActivityResult(
//        ActivityResultContracts.RequestPermission()
//    ) { isGranted ->
//        if (!isGranted) {
//            Toast.makeText(context, "定位权限被拒绝，位置功能不可用", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    LaunchedEffect(Unit) {
//        permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
//    }
//
//    fun getLastLocation(onResult: (String) -> Unit) {
//        val fusedClient = LocationServices.getFusedLocationProviderClient(context)
//
//        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
//            && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
//        ) {
//            onResult("未知")
//            return
//        }
//
//        fusedClient.lastLocation
//            .addOnSuccessListener { location: Location? ->
//                if (location != null) {
//                    val locStr = "${location.latitude},${location.longitude}"
//                    onResult(locStr)
//                } else {
//                    onResult("未知")
//                }
//            }
//            .addOnFailureListener {
//                onResult("未知")
//            }
//    }
//
//    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
//        Text("欢迎, $username 🎉", style = MaterialTheme.typography.titleLarge)
//        Spacer(modifier = Modifier.height(16.dp))
//
//        Button(onClick = {
//            navController.navigate("video_view")
//        }) {
//            Text("观看实时图传")
//        }
//
//        Spacer(modifier = Modifier.height(16.dp))
//
//        Button(onClick = {
//            getLastLocation { loc ->
//                val body = mapOf(
//                    "username" to username,
//                    "location" to loc
//                )
//                if (!isRecording) {
//                    ApiClient.apiService.startRecord(body).enqueue(object : Callback<BaseResponse> {
//                        override fun onResponse(call: Call<BaseResponse>, response: Response<BaseResponse>) {
//                            if (response.body()?.success == true) {
//                                isRecording = true
//                                currentLocation = loc
//                                Toast.makeText(context, "开始录制 (位置: $loc)", Toast.LENGTH_SHORT).show()
//                            } else {
//                                Toast.makeText(context, "开始录制失败", Toast.LENGTH_SHORT).show()
//                            }
//                        }
//                        override fun onFailure(call: Call<BaseResponse>, t: Throwable) {
//                            Toast.makeText(context, "网络错误: ${t.message}", Toast.LENGTH_SHORT).show()
//                        }
//                    })
//                } else {
//                    ApiClient.apiService.stopRecord(body).enqueue(object : Callback<BaseResponse> {
//                        override fun onResponse(call: Call<BaseResponse>, response: Response<BaseResponse>) {
//                            if (response.body()?.success == true) {
//                                isRecording = false
//                                Toast.makeText(context, "停止录制", Toast.LENGTH_SHORT).show()
//                            } else {
//                                Toast.makeText(context, "停止录制失败", Toast.LENGTH_SHORT).show()
//                            }
//                        }
//                        override fun onFailure(call: Call<BaseResponse>, t: Throwable) {
//                            Toast.makeText(context, "网络错误: ${t.message}", Toast.LENGTH_SHORT).show()
//                        }
//                    })
//                }
//            }
//        }) {
//            Text(if (!isRecording) "开始录制" else "停止录制")
//        }
//
//        Spacer(modifier = Modifier.height(8.dp))
//        Text("当前位置: $currentLocation")
//
//        Spacer(modifier = Modifier.height(16.dp))
//
//        Button(onClick = {
//            ApiClient.apiService.listVideos(username).enqueue(object : Callback<VideoListResponse> {
//                override fun onResponse(call: Call<VideoListResponse>, response: Response<VideoListResponse>) {
//                    if (response.body()?.success == true) {
//                        videos = response.body()?.videos ?: listOf()
//                    } else {
//                        Toast.makeText(context, "获取视频失败", Toast.LENGTH_SHORT).show()
//                    }
//                }
//                override fun onFailure(call: Call<VideoListResponse>, t: Throwable) {
//                    Toast.makeText(context, "网络错误: ${t.message}", Toast.LENGTH_SHORT).show()
//                }
//            })
//        }) {
//            Text("刷新视频列表")
//        }
//
//        Spacer(modifier = Modifier.height(16.dp))
//
//        LazyColumn {
//            items(videos) { video ->
//                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
//                    Column(modifier = Modifier.padding(8.dp)) {
//                        Text("文件名: ${video.filename}")
//                        Text("时间: ${video.timestamp}")
//                        Text("位置: ${video.location}")
//                        Text("保存类型: ${video.save_type}")
//                    }
//                }
//            }
//        }
//    }
//}

//  MainScreen.kt
package com.example.srsapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen(username: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("欢迎, $username")
        Spacer(modifier = Modifier.height(8.dp))
        Text("时间戳: 2025.xx.xx")
        Text("位置: xx地")
        Spacer(modifier = Modifier.height(16.dp))
        Image(
            painter = painterResource(id = R.drawable.demo_image),
            contentDescription = "示例图",
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            // 本地录制逻辑
        }, modifier = Modifier.fillMaxWidth()) {
            Text("本地录制")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            // 云端保存逻辑
        }, modifier = Modifier.fillMaxWidth()) {
            Text("云端保存")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            // 查看记录逻辑
        }, modifier = Modifier.fillMaxWidth()) {
            Text("查看记录")
        }
    }
}
