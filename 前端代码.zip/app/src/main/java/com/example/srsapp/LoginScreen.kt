//package com.example.srsapp
//
//import androidx.compose.foundation.layout.*
//import androidx.compose.material.Button
//import androidx.compose.material.Text
//import androidx.compose.material.OutlinedTextField
//import androidx.compose.runtime.*
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.unit.dp
//import androidx.navigation.NavController
//
//@Composable
//fun LoginScreen(
//    navController: NavController,
//    onLoginSuccess: () -> Unit = {},
//    onRegisterClick: () -> Unit = {}
//) {
//    var username by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(16.dp)
//    ) {
//        Text("登录", modifier = Modifier.padding(bottom = 16.dp))
//
//        OutlinedTextField(
//            value = username,
//            onValueChange = { username = it },
//            label = { Text("用户名") },
//            modifier = Modifier.fillMaxWidth()
//        )
//
//        OutlinedTextField(
//            value = password,
//            onValueChange = { password = it },
//            label = { Text("密码") },
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(top = 8.dp)
//        )
//
//        // 登录按钮
//        Button(
//            onClick = {
//                // 这里写你的登录逻辑，比如调用后端接口
//                onLoginSuccess()
//                navController.navigate("main/$username")
//            },
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(top = 16.dp)
//        ) {
//            Text("登录")
//        }
//
//        // 注册按钮
//        Button(
//            onClick = onRegisterClick,
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(top = 8.dp)
//        ) {
//            Text("注册")
//        }
//
//        // 跳过按钮
//        Button(
//            onClick = {
//                navController.navigate("main/guest")
//            },
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(top = 8.dp)
//        ) {
//            Text("跳过（演示）")
//        }
//    }
//}

package com.example.srsapp

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun LoginScreen(
    onLoginSuccess: (String) -> Unit,
    onRegisterClick: () -> Unit,
    onSkipClick: () -> Unit
) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("登录")
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("用户名") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("密码") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            Toast.makeText(context, "模拟点击，无后端请求", Toast.LENGTH_SHORT).show()
            onLoginSuccess(username)
        }, modifier = Modifier.fillMaxWidth()) {
            Text("登录")
        }
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = onRegisterClick, modifier = Modifier.fillMaxWidth()) {
            Text("注册")
        }
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = onSkipClick, modifier = Modifier.fillMaxWidth()) {
            Text("跳过")
        }
    }
}


