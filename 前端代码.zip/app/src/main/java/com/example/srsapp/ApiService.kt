//package com.example.srsapp
//
//import retrofit2.Call
//import retrofit2.http.*
//
//data class UserData(
//    val username: String,
//    val password: String
//)
//
//data class BaseResponse(
//    val success: Boolean,
//    val message: String
//)
//
//data class VideoItem(
//    val filename: String,
//    val timestamp: String,
//    val location: String,
//    val save_type: String
//)
//
//data class VideoListResponse(
//    val success: Boolean,
//    val videos: List<VideoItem>
//)
//
//interface ApiService {
//    @POST("/login")
//    fun login(@Body userData: UserData): Call<BaseResponse>
//
//    @POST("/register")
//    fun register(@Body userData: UserData): Call<BaseResponse>
//
//    @POST("/start_record")
//    fun startRecord(@Body body: Map<String, String>): Call<BaseResponse>
//
//    @POST("/stop_record")
//    fun stopRecord(@Body body: Map<String, String>): Call<BaseResponse>
//
//    @GET("/list_videos")
//    fun listVideos(@Query("username") username: String): Call<VideoListResponse>
//
//    @POST("/delete_video")
//    fun deleteVideo(@Body body: Map<String, String>): Call<BaseResponse>
//}

package com.example.srsapp

import retrofit2.http.Body
import retrofit2.http.POST

data class User(val username: String, val password: String)

interface ApiService {
    @POST("register")
    suspend fun register(@Body user: User): retrofit2.Response<Map<String, Any>>

    @POST("login")
    suspend fun login(@Body user: User): retrofit2.Response<Map<String, Any>>
}
