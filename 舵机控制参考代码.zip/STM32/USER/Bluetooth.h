#ifndef _BLUETOOTH_H_
#define _BLUETOOTH_H_




void InitUart3(void);
void TaskBLEMsgHandle(void);

#endif

